# Sources of this knowledge pack

Pack 1, built 2026-11-27. Every input is pinned by SHA-256; rebuilding from the
same inputs gives the same manifest.json.

## blocklist.txt (blocklist)

- local
  - from: repository: list.txt
  - licence: see source
  - sha256: 5e0119506364b53927280937c548bec1ccdd6ce6fa5676fcc44fc4e6c88892e1

## trusted-os.json (trusted-os)

- default
  - from: repository: tos.json
  - licence: see source
  - sha256: d00cd54cdf83d7f3581fc575279ec496f4a0d0ec9287692e008ceb949451f8b0
